package raven.cell;

public class TableController implements TableActionEvent {

	@Override
	public void onEdit(int row) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onDelete(int row) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onView(int row) {
		// TODO Auto-generated method stub
		
	}

}
